#include<iostream>
#include "name.h"
// Composition
// Aggregation
// Association
// Dependency - 
// Inheritance -- alread familiar with this

using namespace sdds;

namespace subobject {
	class Person {
		Name name_; // composition
		unsigned short age_;
	public:
		Person(const char*, const char*, unsigned short);
		void setData(const char*, const char*, unsigned short);
		void printData() const;
	};

	Person::Person(const char* fn, const char* ln, unsigned short age)
		:name_{ Name(fn,ln) }, age_{ age } {
	}

	void Person::setData(const char* fn, const char* ln, unsigned short age) {
		name_.setFName(fn);
		name_.setLName(ln);
		age_ = age;
	}
	void Person::printData() const {
		std::cout << name_.getName() << ' ' << age_ << std::endl;
	}

}

namespace pointer {

	class Person {
		Name* name_; // composition
		unsigned short age_;
	public:
		Person(const char*, const char*, unsigned short);
		void setData(const char*, const char*, unsigned short);
		void printData() const;
		Person(const Person&);
		Person& operator=(const Person&);
		~Person();
	};

	Person::Person(const char* fn, const char* ln, unsigned short age)
		:name_{ new Name(fn,ln) }, age_{ age } {
	}

	Person::Person(const Person& p) {
		*this = p;
	}
	Person& Person::operator=(const Person& p) {
		if (this != &p) {
			delete name_;
			name_ = new Name(*(p.name_));
			age_ = p.age_;
		}
		return *this;
	}
	Person::~Person() {
		delete name_;
	}
}

/* Composition
Person - Heart
-- A object of class comes into existence as object of another class comes into existence
      and the object object of class ceases to exist as object of another class ceases to exist.
House - Entrance
House - Roof
Person - Name


*/

/* Aggregation
Classroom - Students
YogaClub - Students

*/

/* Association
Doctor - Patient (in walk-in clinic)
SoccorMatch - Audience 


*/

/* Dependency
ClassRoom - InvitedGuestSpeaker


*/


int main() {

	subobject::Person p1("Jack", "Son",23); 
	pointer::Person p2("Son", "Jack", 22);




	return 0;
}