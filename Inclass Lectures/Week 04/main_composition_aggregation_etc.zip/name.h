// filename : name.h 
// ---------------------
#pragma once
#ifndef WEEK4A_EX1_NAME_H
#define WEEK4A_EX1_NAME_H

#define _CRT_SECURE_NO_WARNINGS
#include <string>

namespace sdds {
	class Name {
		char* fname{ nullptr };
		char* lname{ nullptr };
	public:
		Name(const char*, const char*);
		Name(const Name&);
		Name& operator=(const Name&);
		~Name();
		const char* getFName() const;
		const char* getLName() const;
		std::string getName() const;
		void setFName(const char*);
		void setLName(const char*);
	};
}

#endif
