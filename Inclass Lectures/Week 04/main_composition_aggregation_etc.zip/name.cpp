// filename : name.cpp 
// ------------------------
#include "name.h"

namespace sdds {

	Name::Name(const char* fn, const char* ln) :fname{ new char[std::strlen(fn) + 1] },
		lname{ new char[std::strlen(ln) + 1] }{
		std::strcpy(fname, fn);
		std::strcpy(lname, ln);
	}
	Name::Name(const Name& nobj) { *this = nobj; }
	Name& Name::operator=(const Name& nobj) {
		if (this != &nobj) {// guard against self assignment
			delete[] fname;
			delete[] lname;
			fname = new char[std::strlen(nobj.fname) + 1];
			lname = new char[std::strlen(nobj.lname) + 1];
			std::strcpy(fname, nobj.fname);
			std::strcpy(lname, nobj.lname);
		}
		return *this;
	}
	Name::~Name() {
		delete[] fname;
		delete[] lname;
	}
	const char* Name::getFName() const {
		return fname;
	}
	const char* Name::getLName() const {
		return lname;
	}
	std::string Name::getName() const {
		std::string name = fname;
		name.append(" ");
		name.append(lname);
		return name;
	}
	void Name::setFName(const char* fn) {
		delete[] fname;
		fname = new char[std::strlen(fn) + 1];
		std::strcpy(fname, fn);
	}
	void Name::setLName(const char* ln) {
		delete[] lname;
		lname = new char[std::strlen(ln) + 1];
		std::strcpy(lname, ln);
	}

}
