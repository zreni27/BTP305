#include <iostream>
//#include "name.h"
#include "course.h"
#include "room.h"

using namespace sdds;

void book(Course& course, Room& room) {
	course.reserve(room);
	room.reserve(course);
}


int main() {

	Room r1("A3415"), r2("A3212"), r3("B3102");
	Course btp100("Introduction to Programming Using C", 100),
		btp200("Object-Oriented Programming Using C++", 244),
		btp305("Object-Oriented Software Development Using C++", 305);
	r1.printInfo();
	r2.printInfo();
	r3.printInfo();
	btp100.printInfo();
	btp200.printInfo();
	btp305.printInfo();

	book(btp100, r1);
	book(btp305, r2);
	book(btp200, r3);

	r1.printInfo();
	r2.printInfo();
	r3.printInfo();
	btp100.printInfo();
	btp200.printInfo();
	btp305.printInfo();




	return 0;
}