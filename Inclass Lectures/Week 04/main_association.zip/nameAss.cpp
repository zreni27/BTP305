// filename : name.cpp 
// ----------------------
#include "nameAss.h"

namespace sdds {

    Name::Name(const char* name)
        :name_{ new char[std::strlen(name) + 1] } {
        std::strcpy(name_, name);
    }
    Name::Name(const Name& nobj) {
        *this = nobj;
    }
    Name& Name::operator=(const Name& nobj) {
        if (this != &nobj) {
            delete[] name_;
            name_ = new char[std::strlen(nobj.name_) + 1];
            std::strcpy(name_, nobj.name_);
            std::strcpy(name_, nobj.name_);
        }
        return *this;
    }
    Name::~Name() {
        delete[] name_;
    }
    const char* Name::getName() const {
        return name_;
    }
    void Name::setName(const char* name) {
        delete[] name_;
        name_ = new char[std::strlen(name) + 1];
        std::strcpy(name_, name);
    }

}
