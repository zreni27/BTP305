// filename : room.cpp 
// ------------------------
#include <iostream>
#include "room.h"
#include "course.h"

namespace sdds {
	Room::Room(const char* name) :name_{ name } {}
	void Room::reserve(Course& course) {
		if (course_) course_->free();
		course_ = &course;
	}
	void Room::free() { course_ = nullptr; }
	const char* Room::getName() const {
		return name_.getName();
	}
	void Room::printInfo() const {
		std::cout << name_.getName() << ' '
			<< (course_ ? course_->getName() : "available")
			<< std::endl;
	}
}
