// filename : course.cpp 
// -------------------------
#include <iostream>
#include "course.h"
#include "room.h"
#include "nameAss.h"

namespace sdds {
	class Room;

	Course::Course(const char* name, unsigned short code)
		:name_{ name }, code_{ code } {}
	void Course::reserve(Room& room) {
		if (room_) room_->free();
		room_ = &room;
	}
	void Course::free() {
		room_ = nullptr;
	}
	const char* Course::getName() const {
		return name_.getName();
	}
	void Course::printInfo() const {
		std::cout <<
			(room_ ? room_->getName() : "*****")
			<< ' ' << code_ << ' ' << name_.getName()
			<< std::endl;
	}
}