// filename : room.h 
// ---------------------
#ifndef WEEK4A_EX3_ROOM_H
#define WEEK4A_EX3_ROOM_H

#include "nameAss.h"

namespace sdds {

	class Course;

	class Room {
		Name name_;
		Course* course_{ nullptr };
	public:
		Room(const char*);
		void reserve(Course&);
		void free();
		const char* getName() const;
		void printInfo() const;
	};
}

#endif 
