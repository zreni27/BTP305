// filename : course.h 
// ----------------------
#ifndef WEEK4A_EX3_COURSE_H
#define WEEK4A_EX3_COURSE_H

#include "nameAss.h"

namespace sdds {
	class Room;

	class Course {
		Name name_;
		unsigned short code_;
		Room* room_{ nullptr };
	public:
		Course(const char*, unsigned short);
		void reserve(Room&);
		void free();
		const char* getName() const;
		void printInfo() const;

	};


}

#endif 
