// filename : name.h 
// ----------------------
#ifndef WEEK4A_EX3_NAME_H
#define WEEK4A_EX3_NAME_H

#define _CRT_SECURE_NO_WARNINGS
#include <string>

namespace sdds {
    class Name {
        char* name_{ nullptr };
    public:
        Name(const char*);
        Name(const Name&);
        Name& operator=(const Name&);
        ~Name();
        const char* getName() const;
        void setName(const char*);
    };
}

#endif

