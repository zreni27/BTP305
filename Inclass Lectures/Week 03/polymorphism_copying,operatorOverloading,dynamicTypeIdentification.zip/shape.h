// filename : shape.h
// -----------------------
#ifndef SDDS_WK3_EX1_SHAPE3D_H
#define SDDS_WK3_EX1_SHAPE3D_H

namespace sdds {
	class Shape3D {// Interface class, abstract class
	public:
		virtual double getVolume() const = 0;
		virtual double getSurfaceArea() const = 0;
		virtual Shape3D* selfCopy() const = 0;
		virtual bool operator==(Shape3D&) const = 0;
	};
}

#endif
