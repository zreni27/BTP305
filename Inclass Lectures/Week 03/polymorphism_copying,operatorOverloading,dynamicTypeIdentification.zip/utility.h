#ifndef SDDS_WK3_EX1_UTILITY_H
#define SDDS_WK3_EX1_UTLITY_H

#include<iostream>
#include "shape.h"
#include "sphere.h"
#include "cube.h"

namespace sdds {
	// reads dimension of the object
	double readDimension(char ch); 

	// reads user's choice for object
	char menu();

	// creates the object
	Shape3D* createObject();

}

#endif