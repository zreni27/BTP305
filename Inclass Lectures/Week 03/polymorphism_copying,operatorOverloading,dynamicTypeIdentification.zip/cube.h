// filename : cube.h 
// -------------------
#ifndef SDDS_WK3_EX1_CUBE_H
#define SDDS_WK3_EX1_CUBE_H

#include "shape.h"

namespace sdds {

	class Cube : public Shape3D {
		double side_length_;
	public:
		Cube(double);
		double getVolume() const;
		double getSurfaceArea() const;
		Shape3D* selfCopy() const;
		bool operator==(Shape3D&) const;

	};
}

#endif
