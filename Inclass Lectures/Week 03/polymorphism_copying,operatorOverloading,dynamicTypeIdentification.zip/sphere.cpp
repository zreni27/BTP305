// filename : sphere.cpp 
// ------------------------
#include "sphere.h"

namespace sdds {
	Sphere::Sphere(double radius)
		:radius_{ radius > 0 ? radius : 0 } {}
	double Sphere::getVolume() const {
		return (4 / 3) * PI * radius_ * radius_ * radius_;
	}
	double Sphere::getSurfaceArea() const {
		return 4 * PI * radius_ * radius_;
	}
	Shape3D* Sphere::selfCopy() const {
		return new Sphere(*this);
	}
	bool Sphere::operator==(Shape3D& sptr) const {
		Sphere* result = dynamic_cast<Sphere*>(&sptr);
		if (result != nullptr && radius_ == result->radius_)
			return true;
		return false;
	}

}
