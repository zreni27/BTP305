// filename : sphere.h 
// ---------------------
#ifndef SDDS_WK3_EX1_SPHERE_H
#define SDDS_WK3_EX1_SPHERE_H

#include "shape.h"

#define PI 3.14159

namespace sdds {
	class Sphere :public Shape3D {
		double radius_;
	public:
		Sphere(double);
		double getVolume() const;
		double getSurfaceArea() const;
		Shape3D* selfCopy() const;
		bool operator==(Shape3D&) const;
	};
}

#endif
