#include "utility.h"


namespace sdds {

	double readDimension(char ch) {
		double x = 0.0;
		switch (ch) {
		case 's':
			std::cout << "radius: ";
			std::cin >> x;
			break;
		case 'c':
			std::cout << "side length: ";
			std::cin >> x;
			break;
		}
		return x;
	}
	char menu() {
		char ch;
		std::cout << "Enter s for sphere, c for cube: ";
		std::cin >> ch;
		return ch;
	}
	Shape3D* createObject() {
		Shape3D* shptr = nullptr;

		switch (menu()) {
		case 's':
			shptr = new Sphere(readDimension('s'));
			break;
		case 'c':
			shptr = new Cube(readDimension('c'));
			break;
		}
		return shptr;
	}


}