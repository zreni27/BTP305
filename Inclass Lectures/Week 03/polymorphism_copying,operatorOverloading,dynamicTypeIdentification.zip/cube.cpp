// filename : cube.cpp 
// ----------------------
#include "cube.h"

namespace sdds {
	Cube::Cube(double side_length)
		:side_length_{ side_length > 0 ? side_length : 0 } {}

	double Cube::getVolume() const {
		return side_length_ * side_length_ * side_length_;
	}
	double Cube::getSurfaceArea() const {
		return 6 * side_length_ * side_length_;
	}

	Shape3D* Cube::selfCopy() const {
		return new Cube(*this);
	}

	bool Cube::operator==(Shape3D& sptr) const {
		Cube* result = dynamic_cast<Cube*>(&sptr);
		if (result != nullptr && side_length_ == result->side_length_)
			return true;
		return false;
	}
}
