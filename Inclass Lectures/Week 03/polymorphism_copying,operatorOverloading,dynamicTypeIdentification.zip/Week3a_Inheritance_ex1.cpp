// ===============================================
// Week3a_Inheritance_ex1 : polymorphic objects	||
// ===============================================
// This exercise has five modules, main, utility, shape, cube, sphere. The 
// main module shows the client code, and utility module defines several 
// functions, including, readDimension, menu, and createObject. 
// 

#include <iostream>
#include "shape.h"
#include "cube.h"
#include "sphere.h"
#include "utility.h"

using namespace sdds;

void printVolume(const Shape3D* shptr) {
	if (shptr)
		std::cout << "Volume: " << shptr->getVolume() << std::endl;
	else
		std::cout << "object not valid" << std::endl;
}
void printSurfaceArea(const Shape3D* shptr) {
	if (shptr)
		std::cout << "Surface area: " << shptr->getSurfaceArea() << std::endl;
	else
		std::cout << "object not valid" << std::endl;
}
/*
	class Shape3D {// Interface class, abstract class
	public:
		virtual double getVolume() const = 0;
		virtual double getSurfaceArea() const = 0;
		virtual Shape3D* selfCopy() const = 0;
		virtual bool operator==(Shape3D*) const = 0;
	};

*/

void print(Shape3D* sptr) {
	Cube cobj(2.2);
	if (typeid(cobj) == typeid(*sptr)) { // dynamic type identification
		printSurfaceArea(sptr);
	}
	printVolume(sptr);
}

// Square
// Rectangle
// is "Square" a kind of "Rectangle"? yes
// is "Rectangle" a kind of "Square"? yes


int main()
{
	// how to copy dynamic object. 
	// how to make sure that you can use operators for the 
	// dynamic object.

	Shape3D* shptr = nullptr, *shptr2 = nullptr, *shptr3 = nullptr;
	

	for (int i = 0; i < 2; i++) {
		shptr = createObject(); // two types: static type, dynamic type
		shptr2 = shptr->selfCopy();
		shptr3 = createObject();
		print(shptr);
		print(shptr3);
		std::cout << "------- " << std::endl;
		printVolume(shptr);
		printSurfaceArea(shptr);
		printVolume(shptr2);
		printSurfaceArea(shptr2);
		std::cout << shptr << "," << shptr2 << std::endl;

		if (*shptr == *shptr3) { // equal and same
			std::cout << "the objects are equal" << std::endl;
		}
		else {
			std::cout << "the objects are not equal" << std::endl;
		}

		delete shptr;
		delete shptr2;
		delete shptr3;
		printf("\n");
	}
}
